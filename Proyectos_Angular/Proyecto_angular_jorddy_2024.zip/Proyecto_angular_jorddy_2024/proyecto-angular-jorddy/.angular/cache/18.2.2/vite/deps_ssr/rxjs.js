import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_cjs
} from "./chunk-VDZEJD3D.js";
import "./chunk-NQ4HTGF6.js";
export default require_cjs();
//# sourceMappingURL=rxjs.js.map

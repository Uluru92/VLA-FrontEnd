export class PersonaEliminar {

    userName: string;

    constructor(userName: string)
    {
        this.userName = userName;
    }
}
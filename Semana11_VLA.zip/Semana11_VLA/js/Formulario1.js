/*Voy a hacer el load de la pagina*/
$(function(){
    $('#menu-placeholder').load('Menu.html');
})

$(document).ready(function(){
    /*Saludar al mundo por medio de un alert y un console*/
    //alert("Hola, estoy saludando de un alert");
    console.log("Hola, estoy saludando de un console log");
});